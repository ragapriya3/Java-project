import queens.gui.GUI;

public class Main
{
    private static final int BOARD_SIZE = 8;

    public static void main(String[] args)
    {
        GUI i = new GUI(BOARD_SIZE);
        i.setVisible(true);
    }

}
