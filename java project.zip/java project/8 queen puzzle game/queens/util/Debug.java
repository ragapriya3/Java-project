package queens.util;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Debug {

    public static void print(String s) {
        JOptionPane.showMessageDialog(new JFrame(), s);
    }

}
