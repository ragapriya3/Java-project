package queens.game.type;

import java.awt.Color;
import java.awt.Insets;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import queens.game.GameType;
import queens.game.Game;
import queens.gui.GUI;
import queens.util.Debug;

public class Queens extends Game implements GameType {

    public Queens(int row, int col, int gameType) {
        super(row, col, 1);
    }

    public boolean placeMark(JButton[][] btns, int numRow, int numCol) {
        if (isValidCoord(numRow, numCol)) {
            if (isOccupied(numRow, numCol)) {
                Debug.print("Error: Square already occupied, please try again.");
                return false;
            }
            else {
                addComponent(numRow, numCol);
                addComponent2GUI(btns, numRow, numCol);

                hasWon();

                return true;
            }
        }
        return false;
    }

    public void addComponent2GUI(JButton[][] btns, int numRow, int numCol) {
        btns[numRow][numCol].setEnabled(false);
        btns[numRow][numCol].setBackground(Color.BLACK);
        btns[numRow][numCol].setMargin(new Insets(0,0,0,0));
        URL imageLoc = GUI.class.getResource("images/black-queen-2d-icon.png"); // look in the same location as GUI class
        btns[numRow][numCol].setIcon(new ImageIcon(imageLoc));

        for (int i = 0; i < getBoardWidth(); i++)
        {
            btns[i][numCol].setEnabled(true);
            /* Disable the whole row (including the one we clicked on) */
            btns[numRow][i].setEnabled(false);
        }

        for (int i = numRow, k = numCol; i < getBoardWidth(); i++, k++)
        {
            if (isValidCoord(i, k))
                btns[i][k].setEnabled(false);
        }

        for (int c = numRow, j = numCol; c >= 0; c--, j--)
        {
            if (isValidCoord(c, j))
                    btns[c][j].setEnabled(false);
        }

        for (int i = numRow, k = numCol; i < getBoardWidth(); i++, k--)
        {
            if (isValidCoord(i, k))
                btns[i][k].setEnabled(false);
        }

        for (int c = numRow, j = numCol; c >= 0; c--, j++)
        {
            if (isValidCoord(c, j))
                btns[c][j].setEnabled(false);
        }
    }


    public void addComponent(int numRow, int numCol) {
        setSquare(numRow, numCol);
        incCounter();

        for (int i = 0; i < getBoardWidth(); i++)
        {
            setSquare(i, numCol);
            setSquare(numRow, i);
        }
       
        for (int i = numRow, k = numCol; i < getBoardWidth(); i++, k++)
        {
            if (isValidCoord(i, k))
                setSquare(i, k);
        }

        for (int c = numRow, j = numCol; c >= 0; c--, j--)
        {
            if (isValidCoord(c, j))
                setSquare(c, j);
        }

        for (int i = numRow, k = numCol; i < getBoardWidth(); i++, k--)
        {
            if (isValidCoord(i, k))
                setSquare(i, k);
        }

        for (int c = numRow, j = numCol; c >= 0; c--, j++)
        {
            if (isValidCoord(c, j))
                setSquare(c, j);
        }
    }


    public void unset(JButton[][] btns, int numRow, int numCol) {
        decCounter();

        for (int i = 0; i < getBoardWidth(); i++)
        {
            unsetSquare(i, numCol);
            unsetSquare(numRow, i);
        }

        for (int i = numRow, k = numCol; i < getBoardWidth(); i++, k++)
        {
            if (isValidCoord(i, k))
                unsetSquare(i, k);
        }

        for (int c = numRow, j = numCol; c >= 0; c--, j--)
        {
            if (isValidCoord(c, j))
                unsetSquare(c, j);
        }

        for (int i = numRow, k = numCol; i < getBoardWidth(); i++, k--)
        {
            if (isValidCoord(i, k))
                unsetSquare(i, k);
        }

        for (int c = numRow, j = numCol; c >= 0; c--, j++)
        {
            if (isValidCoord(c, j))
                unsetSquare(c, j);
        }

        unset(btns);
    }

}
