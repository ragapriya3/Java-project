package queens.game;

import javax.swing.JButton;

public interface GameType {

    public boolean placeMark(JButton[][] btns, int numRow, int numCol);
    public void addComponent2GUI(JButton[][] btns, int numRow, int numCol);
    public void addComponent(int numRow, int numCol);
    public void unset(JButton[][] btns, int numRow, int numCol);

}
