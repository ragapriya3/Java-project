package queens.game;

import javax.swing.JButton;
import javax.swing.UIManager;
import queens.gui.GUI;
import queens.util.Debug;

public class Game extends Board {

    private int gameType = 1;
    private int gameCounter = 0;

    private final int initChar = 0;

    public Game(int numRows, int numCols, int gameType) {
        super(numRows, numCols);
        this.gameType = 1;
        initialise();
    }

    public boolean isOccupied(int numRow, int numCol) {
        if (getSquare(numRow, numCol) != initChar)
            return true;
        else
            return false;
    }

    public boolean hasWon() {
        // Check Queens
        if (gameType == 1) {
            if (getCounter() < 8 && boardFull()) {
                Debug.print("You failed to complete the puzzle. \nClick reset to try again.");
                return true; // stop the game
            }

            else if (getCounter() == 8) {
                for (int i = 0; i < getBoardWidth(); i++) {
                    for (int k = 0; k < getBoardHeight(); k++) {
                        if (getSquare(i, k) == initChar) {
                            Debug.print("You failed to complete the puzzle. \nClick reset to try again.");
                            return true; // stop the game
                        }
                    }
                }

                Debug.print("CONGRATULATIONS YOU SOLVED THE PUZZLE!!");
                return true;
            }
        }
        return false;
    }

    public void unset(JButton[][] btns) {
        for (int i = 0; i < getBoardWidth(); i++) {
            for (int k = 0; k < getBoardHeight(); k++) {
                // Check if the square is under attack
                if (getSquare(i,k) == 0) {
                    btns[i][k].setEnabled(true);
                    btns[i][k].setIcon(null);
                    btns[i][k].setEnabled(true);
                    btns[i][k].setBackground(UIManager.getColor("Button.background"));
                }
            }
        }
    }
    public int getCounter() {
        return gameCounter;
    }

    public void decCounter() {
        this.gameCounter--;
        GUI.updateCounter(getCounter());
    }


    public void incCounter() {
        this.gameCounter++;
        GUI.updateCounter(getCounter());
    }

    public void resetCounter() {
        this.gameCounter = 0;
    }

    public void resetGameType() {
        this.gameType = 1;
    }
    
}
