package queens.game;

public class Board {
	
    private int numRows;
    private int numCols;
    private final int initChar = 0;

    private int[][] board;

    public Board(int numRows, int numCols) {
        this.numRows = numRows;
        this.numCols = numCols;

        board = new int[numRows][numCols];
    }

    public void display() {
        for (int i = 0; i < board.length; i++) {
            System.out.print("\t");
            for (int k = 0; k < board[0].length; k++) {
                System.out.print(board[i][k] + " ");
            }
            System.out.print("\n");
        }
    }

    public void initialise() {
        for (int i = 0; i < board.length; i++) {
            for (int k = 0; k < board[0].length; k++) {
                board[i][k] = initChar;
            }
        }
    }

    public boolean boardFull() {
        for (int i = 0; i < board[0].length; i++) {
            for (int k = 0; k < board.length; k++) {
                if (board[i][k] == initChar)
                    return false;
            }
        }
        return true;
    }

    public boolean isValidCoord(int numRow, int numCol) {
        if ((numRow >= 0 && numRow < this.numRows) && (numCol >= 0 && numCol < this.numCols))
            return true;

        else {
            return false;
        }
    }

    public int getSquare(int numRow, int numCol) {
        if (isValidCoord(numRow, numCol))
            return board[numRow][numCol];
        
        else
            return (Character) null;
    }

    public void setSquare(int numRow, int numCol) {
        if (isValidCoord(numRow, numCol))
            board[numRow][numCol] += 1;
    }

    public void unsetSquare(int numRow, int numCol) {
        if (isValidCoord(numRow, numCol))
        {
            if (board[numRow][numCol] > 0)
                board[numRow][numCol] -= 1;
        }
    }

    public int getBoardWidth() {
        return board[0].length;
    }

    public int getBoardHeight() {
        return board.length;
    }

}
