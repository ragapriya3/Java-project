package queens.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import queens.game.type.*;
import queens.game.Game;
import queens.util.Debug;

public class GUI extends JFrame implements ActionListener {
public int board_size = 8;
JButton[][] btns;

    JComboBox gameModes = new JComboBox(new String[] {"Queens"});
    static JProgressBar progressBar = null;
    JButton resetButton = new JButton("Reset");
    
    public Game game;
    public Queens queens = null; 
    
    public int gameType = 1;

    public GUI(int boardSize) {
        board_size = boardSize;

        setTitle("8 Queens Puzzle");

        JPanel bgPnl = new JPanel(new BorderLayout());
        setContentPane(bgPnl);

        JPanel topPanel = new JPanel(new BorderLayout());

        JLabel title = new JLabel("8 - Queens Puzzle", JLabel.CENTER);     // Title of the GUI
        title.setFont(new Font("Times Roman BOLD", Font.ITALIC, 24)); // Set the font to large
        topPanel.add(title, BorderLayout.NORTH);

        JLabel gameModeLabel = new JLabel("Select Game mode: ");
        gameModeLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0)); // set padding around the element
        topPanel.add(gameModeLabel, BorderLayout.WEST);
        
        gameModes.setPreferredSize(new Dimension(70, 10)); // set size of component
        gameModes.addActionListener(this);
        gameModes.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0)); // set padding around the element (matching label)
        topPanel.add(gameModes, BorderLayout.EAST);

        bgPnl.add(topPanel, BorderLayout.NORTH); // Add panel to the content pane

        /**
         * Game grid initialised and managed here
         */
        JPanel gridPanel = new JPanel(new GridLayout(board_size + 1, board_size));
        btns = new JButton[board_size][board_size];
        
        for (int i = 0; i < board_size; i++) {
            for (int k = 0; k < board_size; k++) {
                btns[i][k] = new JButton(" ");
                btns[i][k].setPreferredSize(new Dimension(40, 30));

                final int numRow = i, numCol = k; // provide variable access to actionlistener class

                // Add a mouse listener to detect when the disabled buttons are clicked
                btns[i][k].addMouseListener(new MouseListener() 
                {

                    public void mouseClicked(MouseEvent e) {
                        
                        if (btns[numRow][numCol].isEnabled() && btns[numRow][numCol].getBackground() == Color.BLACK)
                        {
                            if (gameType == 1 && queens != null)
                                queens.unset(btns, numRow, numCol);
                        }
                        else
                        {
                            if(gameType != 0) // ensure game type is selected to avoid exception errors..
                            {
                                if (!game.hasWon())
                                {
                                    if (gameType == 1 && queens != null)
                                        queens.placeMark(btns, numRow, numCol);

                                }
                            }
                        }
                    }

                    public void mousePressed(MouseEvent e) { }

                    public void mouseReleased(MouseEvent e) { }

                    public void mouseEntered(MouseEvent e) { }

                    public void mouseExited(MouseEvent e) { }

                    
                });

                gridPanel.add(btns[i][k]);
            }
        }
        bgPnl.add(gridPanel, BorderLayout.CENTER);

        JPanel bottomPnl = new JPanel(new BorderLayout());

        JPanel internalPnl1 = new JPanel(new BorderLayout());
        progressBar = new JProgressBar(0, 0); // we'll initiaise the maximum value when the game type is selected
        progressBar.setValue(0);

        // add panel to the bottom house
        bottomPnl.add(internalPnl1, BorderLayout.NORTH);

        JPanel internalPnl2 = new JPanel(new FlowLayout());
        resetButton.addActionListener(this);
        internalPnl2.add(resetButton);

        bottomPnl.add(internalPnl2, BorderLayout.SOUTH);
        bgPnl.add(bottomPnl, BorderLayout.SOUTH); // add bottom panel to the content pane

        pack();
    }

    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == resetButton)
        {
            resetGame();
        }

        else if (e.getSource() == gameModes && gameModes.getSelectedItem() == "Queens")
        {
            gameType = 1;
            game = queens = new Queens(board_size, board_size, gameType);
            progressBar.setMaximum(8); 
            disableGameTypes();
        }
    }

    private void enableGameTypes() {
        gameModes.setEnabled(true);
    }

    private void disableGameTypes() {
        gameModes.setEnabled(false);
    }

    public static void updateCounter(int num) {
        if (num < progressBar.getValue()) {
            int update = progressBar.getValue() - 1;

            progressBar.setValue(update);
            progressBar.setString(Integer.toString(update));
        }
        else if (num > progressBar.getValue()) {
            int update = progressBar.getValue() + 1;

            progressBar.setValue(update);
            progressBar.setString(Integer.toString(update));
        }
    }

    private void resetGame() {
        for (int i = 0; i < btns[0].length; i++) {
            for (int k = 0; k < btns.length; k++) {
                btns[i][k].setIcon(null);
                btns[i][k].setEnabled(true);
                btns[i][k].setBackground(UIManager.getColor("Button.background"));
            }
        }

        gameType = 1; // reset game type (force re-check to avoid bugs..)
        progressBar.setValue(0);
        progressBar.setString("0");
        enableGameTypes(); // re-enable all the GUI components

        game.initialise(); // reset the board to default character
        game.resetCounter();
        game.resetGameType();
    }

}
